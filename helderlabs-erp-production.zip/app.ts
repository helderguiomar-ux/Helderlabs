import { setupWebsocket } from './websocket';
import path from 'node:path';
import Fastify from 'fastify';
import cors from '@fastify/cors';
import fastifyStatic from '@fastify/static';
import { ZodError } from 'zod';
import authenticatePlugin from './plugins/authenticate';
import { authRoutes } from './modules/auth/routes/auth.routes';
import { crmRoutes } from './modules/crm/routes/crm.routes';
import { condominiosRoutes } from './modules/condominios/routes/condominios.routes';
import { platformRoutes } from './modules/platform/routes/platform.routes';
import { checkDatabaseReady } from './database/prisma/client';

export function buildApp() {
  const app = Fastify({
    logger: true
  });

  app.register(cors, { origin: true });

  // Todas as rotas validam input com `algumSchema.parse(request.x)` (zod),
  // em vez de usar a validação de schema nativa do Fastify — o que é
  // ótimo para os tipos, mas significa que um input inválido lança um
  // ZodError que, sem isto, cai no handler de erro por omissão do Fastify
  // e vira sempre 500. Descoberto a testar `/api/auth/oauth/:provider/start`
  // com um provider inexistente (devia ser 400, "pedido inválido", não 500,
  // "rebentou o servidor"). Isto corrige isso para TODAS as rotas de uma
  // vez, sem ter de alterar cada rota uma a uma.
  app.setErrorHandler((error, request, reply) => {
    if (error instanceof ZodError) {
      return reply.status(400).send({
        message: 'Pedido inválido.',
        issues: error.issues.map((issue) => ({ path: issue.path.join('.'), message: issue.message }))
      });
    }
    request.log.error(error);
    return reply.status((error as any).statusCode ?? 500).send({
      message: error.message || 'Erro interno do servidor.'
    });
  });

  // Expõe `app.authenticate` (preHandler) e decora request.user/request.db.
  // Registado antes de qualquer rota que dependa dele.
  app.register(authenticatePlugin);

  // Frontend estático mínimo (public/index.html) — dá para "usar" o CRM
  // com cliques em vez de chamadas diretas à API. Serve em "/", por isso
  // é registado antes das rotas de API para não colidir com os prefixos
  // /api/auth e /api/crm.
  app.register(fastifyStatic, {
    root: path.join(__dirname, '../public'),
    prefix: '/',
    index: 'index.html'
  });

  // DB Guard para as APIs (Não aplica aos ficheiros estáticos /public)
  app.addHook('onRequest', async (request, reply) => {
    if (request.url.startsWith('/api/') && request.url !== '/api/health') {
      const isDbReady = await checkDatabaseReady();
      if (!isDbReady) {
        return reply.status(503).send({
          error: 'DATABASE_UNAVAILABLE',
          message: 'O serviço está temporariamente indisponível. A base de dados está em inicialização ou recuperação.'
        });
      }
    }
  });

  app.get('/api/health', async () => {
    const isDbReady = await checkDatabaseReady(true);
    return {
      application: 'healthy',
      database: isDbReady ? 'ready' : 'unavailable',
      authentication: isDbReady ? 'healthy' : 'degraded',
      version: process.env.VERSION || '0.1.0',
      environment: process.env.ENVIRONMENT || 'DEVELOPMENT'
    };
  });

  // Antiga rota de health, mantemos /health por compatibilidade e apontamos para api/health
  app.get('/health', async (request, reply) => {
    reply.redirect('/api/health');
  });

  // Login/sessão — não exige autenticação prévia (é aqui que ela começa).
  app.register(authRoutes, { prefix: '/api/auth' });

  // Plataforma / Super Admin — O middleware interno garante acesso apenas a SUPER_ADMIN
  app.register(platformRoutes, { prefix: '/api/platform' });

  // Rotas públicas (ex: Pedido de conta)
  

  // GLOBAL ERROR BOUNDARY
  app.setErrorHandler((error, request, reply) => {
    app.log.error({ err: error, reqId: request.id }, 'Internal server error');
    
    // Tratamento de erros do Prisma (Recovery / Indisponibilidade)
    if (error.message && (error.message.includes('FATAL: the database system is in recovery mode') || error.message.includes('Can\'t reach database server'))) {
      return reply.status(503).send({
        error: 'DATABASE_UNAVAILABLE',
        message: 'O serviço está temporariamente indisponível. Estamos a preparar/recuperar o sistema.',
        details: 'Tente novamente em breves instantes.'
      });
    }

    if (error.name === 'PrismaClientInitializationError' || error.name === 'PrismaClientKnownRequestError') {
      return reply.status(503).send({
        error: 'DATABASE_UNAVAILABLE',
        message: 'O serviço está temporariamente indisponível.',
      });
    }

    // Default error
    reply.status(500).send({
      error: 'INTERNAL_ERROR',
      message: 'Ocorreu um erro interno. A nossa equipa já foi notificada.'
    });
  });

  // Cada módulo regista as suas rotas sob o próprio prefixo — isto é o que
  // mantém o backend modular à medida que Vendas, Faturação, Financeiro e
  // Tarefas forem sendo implementados. Todas exigem JWT válido (ver
  // crm.routes.ts -> app.addHook('preHandler', app.authenticate)).
  app.register(crmRoutes, { prefix: '/api/crm' });

  // Gestão de Condomínios — CRUD mínimo (Building + Unit) para provar o
  // modelo de dados na prática (ver README). Mesmo contrato dos outros
  // módulos: JWT obrigatório, tenantId nunca vindo do cliente.
  app.register(condominiosRoutes, { prefix: '/api/condominios' });

  setupWebsocket(app);
  return app;
}
