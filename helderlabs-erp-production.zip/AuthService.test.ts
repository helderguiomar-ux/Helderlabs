import { test, describe, before } from 'node:test';
import assert from 'node:assert/strict';
import {
  AuthService,
  InactiveUserError,
  InvalidCredentialsError,
  OAuthOnlyAccountError,
  OAuthEmailNotVerifiedError,
  UnknownAccountError,
  PLATFORM_TENANT_ID,
  hashPassword
} from '../../src/modules/auth/services/AuthService';

// JWT_SECRET tem de existir antes de importar AuthService (signAuthToken lê
// process.env.JWT_SECRET só quando é chamado, por isso definir aqui, no
// arranque do ficheiro de teste, é suficiente).
process.env.JWT_SECRET = process.env.JWT_SECRET ?? 'segredo-de-teste';

const SUPER_ADMIN_EMAIL = 'helderguiomar@gmail.com';

function buildFakeRepo(users: any[] = [], tenants: any[] = []) {
  return {
    user: {
      findUnique: async ({ where }: any) => users.find((u) => u.email === where.email) ?? null,
      create: async ({ data }: any) => {
        const user = { id: `user_${users.length + 1}`, createdAt: new Date(), ...data };
        users.push(user);
        return user;
      },
      update: async ({ where, data }: any) => {
        const user = users.find((u) => u.id === where.id);
        if (!user) throw new Error(`Utilizador ${where.id} não existe no fake repo.`);
        Object.assign(user, data);
        return user;
      }
    },
    tenant: {
      upsert: async ({ where, create }: any) => {
        let tenant = tenants.find((t) => t.id === where.id);
        if (!tenant) {
          tenant = { ...create };
          tenants.push(tenant);
        }
        return tenant;
      }
    },
    __seed: { users, tenants }
  } as any;
}

// process.env.DEFAULT_SUPER_ADMIN_EMAIL é lido a cada login (não cacheado),
// por isso é seguro só definir/limpar à volta dos testes que precisam dele
// sem afetar os restantes.
function withSuperAdminEnv<T>(fn: () => Promise<T>): Promise<T> {
  const original = process.env.DEFAULT_SUPER_ADMIN_EMAIL;
  process.env.DEFAULT_SUPER_ADMIN_EMAIL = SUPER_ADMIN_EMAIL;
  return fn().finally(() => {
    if (original === undefined) delete process.env.DEFAULT_SUPER_ADMIN_EMAIL;
    else process.env.DEFAULT_SUPER_ADMIN_EMAIL = original;
  });
}

describe('AuthService — login por email/password', () => {
  let passwordHash: string;

  before(async () => {
    passwordHash = await hashPassword('palavra-passe-correta');
  });

  test('login: emite um token válido para credenciais corretas', async () => {
    const db = buildFakeRepo([
      {
        id: 'user_1',
        tenantId: 'tenant_1',
        name: 'Utilizador Demo',
        email: 'demo@helderlabs.pt',
        passwordHash,
        role: 'ADMIN',
        active: true
      }
    ]);
    const service = new AuthService(db);

    const result = await service.login('demo@helderlabs.pt', 'palavra-passe-correta');

    assert.ok(result.token, 'deve devolver um token');
    assert.equal(result.user.tenantId, 'tenant_1');
    assert.equal(result.user.role, 'ADMIN');
    assert.equal(result.user.email, 'demo@helderlabs.pt');
  });

  test('login: rejeita password errada', async () => {
    const db = buildFakeRepo([
      { id: 'user_1', tenantId: 'tenant_1', name: 'X', email: 'demo@helderlabs.pt', passwordHash, role: 'ADMIN', active: true }
    ]);
    const service = new AuthService(db);

    await assert.rejects(() => service.login('demo@helderlabs.pt', 'password-errada'), InvalidCredentialsError);
  });

  test('login: rejeita email inexistente sem distinguir da password errada (não revela quais emails existem)', async () => {
    const db = buildFakeRepo([]);
    const service = new AuthService(db);

    await assert.rejects(() => service.login('ninguem@helderlabs.pt', 'qualquer-coisa'), InvalidCredentialsError);
  });

  test('login: rejeita utilizador inativo mesmo com password correta', async () => {
    const db = buildFakeRepo([
      { id: 'user_1', tenantId: 'tenant_1', name: 'X', email: 'demo@helderlabs.pt', passwordHash, role: 'ADMIN', active: false }
    ]);
    const service = new AuthService(db);

    await assert.rejects(() => service.login('demo@helderlabs.pt', 'palavra-passe-correta'), InactiveUserError);
  });

  test('login: rejeita conta sem passwordHash (criada via OAuth) mesmo com o email certo', async () => {
    const db = buildFakeRepo([
      {
        id: 'user_1',
        tenantId: 'tenant_1',
        name: 'X',
        email: 'oauth-only@helderlabs.pt',
        passwordHash: null,
        authProvider: 'GOOGLE',
        role: 'USER',
        active: true
      }
    ]);
    const service = new AuthService(db);

    await assert.rejects(() => service.login('oauth-only@helderlabs.pt', 'qualquer-coisa'), OAuthOnlyAccountError);
  });

  test('login: promove automaticamente a SUPER_ADMIN quando o email é o DEFAULT_SUPER_ADMIN_EMAIL', () =>
    withSuperAdminEnv(async () => {
      const db = buildFakeRepo([
        { id: 'user_1', tenantId: 'tenant_1', name: 'Helder', email: SUPER_ADMIN_EMAIL, passwordHash, role: 'USER', active: true }
      ]);
      const service = new AuthService(db);

      const result = await service.login(SUPER_ADMIN_EMAIL, 'palavra-passe-correta');

      assert.equal(result.user.role, 'SUPER_ADMIN');
      assert.equal(db.__seed.users[0].role, 'SUPER_ADMIN', 'a promoção deve ficar persistida, não só na resposta');
    }));

  test('login: NÃO promove um email diferente, mesmo que pareça semelhante', () =>
    withSuperAdminEnv(async () => {
      const db = buildFakeRepo([
        { id: 'user_1', tenantId: 'tenant_1', name: 'X', email: 'nao-e-o-super-admin@gmail.com', passwordHash, role: 'USER', active: true }
      ]);
      const service = new AuthService(db);

      const result = await service.login('nao-e-o-super-admin@gmail.com', 'palavra-passe-correta');

      assert.equal(result.user.role, 'USER');
    }));
});

describe('AuthService — login social (OAuth)', () => {
  test('loginOrRegisterWithOAuth: cria automaticamente o SUPER_ADMIN no primeiro login (email nunca visto antes)', () =>
    withSuperAdminEnv(async () => {
      const db = buildFakeRepo([], []);
      const service = new AuthService(db);

      const result = await service.loginOrRegisterWithOAuth({
        provider: 'google',
        subject: 'google-sub-123',
        email: SUPER_ADMIN_EMAIL,
        emailVerified: true
      });

      assert.equal(result.user.role, 'SUPER_ADMIN');
      assert.equal(result.user.tenantId, PLATFORM_TENANT_ID);
      assert.equal(db.__seed.tenants.length, 1, 'deve criar o tenant da plataforma');
      assert.equal(db.__seed.users[0].oauthSubject, 'google-sub-123');
      assert.equal(db.__seed.users[0].authProvider, 'GOOGLE');
    }));

  test('loginOrRegisterWithOAuth: rejeita um email desconhecido que NÃO é o super admin (sem convite, sem conta)', async () => {
    const db = buildFakeRepo([], []);
    const service = new AuthService(db);

    await assert.rejects(
      () =>
        service.loginOrRegisterWithOAuth({
          provider: 'microsoft',
          subject: 'sub-x',
          email: 'desconhecido@qualquercoisa.pt',
          emailVerified: true
        }),
      UnknownAccountError
    );
    assert.equal(db.__seed.users.length, 0, 'não deve criar nenhum tenant/utilizador para um email desconhecido');
  });

  test('loginOrRegisterWithOAuth: rejeita email não verificado pelo provider, mesmo sendo o super admin', () =>
    withSuperAdminEnv(async () => {
      const db = buildFakeRepo([], []);
      const service = new AuthService(db);

      await assert.rejects(
        () =>
          service.loginOrRegisterWithOAuth({
            provider: 'apple',
            subject: 'sub-y',
            email: SUPER_ADMIN_EMAIL,
            emailVerified: false
          }),
        OAuthEmailNotVerifiedError
      );
    }));

  test('loginOrRegisterWithOAuth: associa a conta social a um utilizador EMAIL já existente (mesmo email)', async () => {
    const db = buildFakeRepo(
      [{ id: 'user_1', tenantId: 'tenant_1', name: 'Maria', email: 'maria@acme.pt', passwordHash: 'x', authProvider: 'EMAIL', oauthSubject: null, role: 'USER', active: true }],
      []
    );
    const service = new AuthService(db);

    const result = await service.loginOrRegisterWithOAuth({
      provider: 'google',
      subject: 'google-sub-maria',
      email: 'maria@acme.pt',
      emailVerified: true
    });

    assert.equal(result.user.id, 'user_1', 'deve reutilizar a conta existente, não criar uma nova');
    assert.equal(db.__seed.users[0].authProvider, 'GOOGLE');
    assert.equal(db.__seed.users[0].oauthSubject, 'google-sub-maria');
  });

  test('loginOrRegisterWithOAuth: rejeita utilizador existente mas inativo', async () => {
    const db = buildFakeRepo(
      [{ id: 'user_1', tenantId: 'tenant_1', name: 'X', email: 'inativo@acme.pt', authProvider: 'EMAIL', oauthSubject: null, role: 'USER', active: false }],
      []
    );
    const service = new AuthService(db);

    await assert.rejects(
      () =>
        service.loginOrRegisterWithOAuth({
          provider: 'google',
          subject: 'sub-z',
          email: 'inativo@acme.pt',
          emailVerified: true
        }),
      InactiveUserError
    );
  });
});
