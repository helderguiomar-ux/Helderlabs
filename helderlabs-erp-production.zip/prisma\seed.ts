import { PrismaClient, UserRole, UserStatus, TenantStatus } from '@prisma/client';
import bcrypt from 'bcrypt';

const prisma = new PrismaClient();

async function main() {
  // Encontrar ou criar Tenant de Demo
  let tenant = await prisma.tenant.findUnique({ where: { slug: 'demo' } });
  if (!tenant) {
    tenant = await prisma.tenant.create({
      data: {
        name: 'Empresa de Demonstra��o',
        slug: 'demo',
        status: TenantStatus.ACTIVE,
      }
    });
  }

  // Encontrar ou criar Demo User
  const passwordHash = await bcrypt.hash('demo', 10);
  
  await prisma.user.upsert({
    where: { email: 'demo@helderlabs.eu' },
    update: {
      passwordHash,
      status: UserStatus.ACTIVE,
      role: UserRole.USER
    },
    create: {
      email: 'demo@helderlabs.eu',
      name: 'Utilizador Demo',
      passwordHash,
      status: UserStatus.ACTIVE,
      role: UserRole.USER,
      tenantId: tenant.id
    }
  });

  console.log('Seed completo: demo@helderlabs.eu criado.');
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
